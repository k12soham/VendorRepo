import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import EmployeeComponent from './components/EmployeeComponent';
import VendorComponent from './components/VendorComponent';
import EmailLogComponent from './components/EmailLogComponent';
import './App.css'; 

function App() {
    return (
        <Router>
            <div>
                <nav>
                    <ul>
                        <li><Link to="/employees">Employees</Link></li>
                        <li><Link to="/vendors">Vendors</Link></li>
                        <li><Link to="/email-logs">Email Logs</Link></li>
                    </ul>
                </nav>
                <div className="container">
                    <Routes>
                        <Route path="/employees" element={<EmployeeComponent />} />
                        <Route path="/vendors" element={<VendorComponent />} />
                        <Route path="/email-logs" element={<EmailLogComponent />} />
                    </Routes>
                </div>
            </div>
        </Router>
    );
}

export default App;
