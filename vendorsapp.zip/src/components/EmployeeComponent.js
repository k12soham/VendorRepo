import React, { useState, useEffect } from 'react';
import { getAllEmployees, saveEmployee } from '../services/Api';

const EmployeeComponent = () => {
    const [employees, setEmployees] = useState([]);
    const [employee, setEmployee] = useState({
        name: '',
        designation: '',
        ctc: '',
        email: '',
    });

    useEffect(() => {
        fetchEmployees();
    }, []);

    const fetchEmployees = async () => {
        try {
            const response = await getAllEmployees();
            setEmployees(response.data);
        } catch (error) {
            console.error('Error fetching employees:', error);
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setEmployee({ ...employee, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await saveEmployee(employee);
            fetchEmployees();
            setEmployee({ name: '', designation: '', ctc: '', email: '' });
        } catch (error) {
            console.error('Error saving employee:', error);
        }
    };

    return (
        <div className="container">
            <h2>Employees</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="name" value={employee.name} onChange={handleChange} placeholder="Name" required />
                <input type="text" name="designation" value={employee.designation} onChange={handleChange} placeholder="Designation" required />
                <input type="number" name="ctc" value={employee.ctc} onChange={handleChange} placeholder="CTC" required />
                <input type="email" name="email" value={employee.email} onChange={handleChange} placeholder="Email" required />
                <button type="submit">Save Employee</button>
            </form>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Designation</th>
                        <th>CTC</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    {employees.map((emp) => (
                        <tr key={emp.id}>
                            <td>{emp.name}</td>
                            <td>{emp.designation}</td>
                            <td>{emp.ctc}</td>
                            <td>{emp.email}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default EmployeeComponent;
