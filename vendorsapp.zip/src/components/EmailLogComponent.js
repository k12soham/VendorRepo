import React, { useState, useEffect } from 'react';
import { getAllEmailLogs } from '../services/Api';

const EmailLogComponent = () => {
    const [emailLogs, setEmailLogs] = useState([]);

    useEffect(() => {
        fetchEmailLogs();
    }, []);

    const fetchEmailLogs = async () => {
        try {
            const response = await getAllEmailLogs();
            setEmailLogs(response.data);
        } catch (error) {
            console.error('Error fetching email logs:', error);
        }
    };

    return (
        <div className="container">
            <h2>Email Logs</h2>
            <table>
                <thead>
                    <tr>
                        <th>Subject</th>
                        <th>Email</th>
                        <th>Sent At</th>
                        <th>Body</th>
                    </tr>
                </thead>
                <tbody>
                    {emailLogs.map((log) => (
                        <tr key={log.id}>
                            <td><strong>{log.subject}</strong></td>
                            <td>{log.email}</td>
                            <td>{new Date(log.sentAt).toLocaleString()}</td>
                            <td className="email-body" dangerouslySetInnerHTML={{ __html: log.body }}></td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default EmailLogComponent;
