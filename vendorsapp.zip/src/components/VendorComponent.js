import React, { useState, useEffect } from 'react';
import { getAllVendors, saveVendor, sendEmailToSelectedVendors } from '../services/Api';

const VendorComponent = () => {
    const [vendors, setVendors] = useState([]);
    const [vendor, setVendor] = useState({
        name: '',
        email: '',
        upi: '',
    });
    const [selectedVendors, setSelectedVendors] = useState([]);
    const [loading, setLoading] = useState(false); 

    useEffect(() => {
        fetchVendors();
    }, []);

    const fetchVendors = async () => {
        setLoading(true); 
        try {
            const response = await getAllVendors();
            setVendors(response.data);
        } catch (error) {
            console.error('Error fetching vendors:', error);
        } finally {
            setLoading(false); 
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setVendor({ ...vendor, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true); 
        try {
            await saveVendor(vendor);
            fetchVendors();
            setVendor({ name: '', email: '', upi: '' });
        } catch (error) {
            console.error('Error saving vendor:', error);
        } finally {
            setLoading(false); 
        }
    };

    const handleCheckboxChange = (vendorId) => {
        if (selectedVendors.includes(vendorId)) {
            setSelectedVendors(selectedVendors.filter((id) => id !== vendorId));
        } else {
            setSelectedVendors([...selectedVendors, vendorId]);
        }
    };

    const handleSendEmail = async () => {
        setLoading(true); 
        try {
            await sendEmailToSelectedVendors(selectedVendors);
            alert('Emails sent successfully');
            setSelectedVendors([]);
        } catch (error) {
            console.error('Error sending emails:', error);
        } finally {
            setLoading(false); 
        }
    };

    return (
        <div className="container">
            <h2>Vendors</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="name" value={vendor.name} onChange={handleChange} placeholder="Name" required />
                <input type="email" name="email" value={vendor.email} onChange={handleChange} placeholder="Email" required />
                <input type="text" name="upi" value={vendor.upi} onChange={handleChange} placeholder="UPI" required />
                <button type="submit">Save Vendor</button>
            </form>
            <div className="button-container">
                <button 
                    className="send-email-button"
                    onClick={handleSendEmail}
                    disabled={selectedVendors.length === 0 || loading} 
                >
                    Send Emails to Selected Vendors
                </button>
            </div>
            {loading && <div className="loader">Loading...</div>}
            {!loading && (
                <table>
                    <thead>
                        <tr>
                            <th>Select</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>UPI</th>
                        </tr>
                    </thead>
                    <tbody>
                        {vendors.map((ven) => (
                            <tr key={ven.id}>
                                <td>
                                    <input
                                        type="checkbox"
                                        checked={selectedVendors.includes(ven.id)}
                                        onChange={() => handleCheckboxChange(ven.id)}
                                    />
                                </td>
                                <td>{ven.name}</td>
                                <td>{ven.email}</td>
                                <td>{ven.upi}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
};

export default VendorComponent;
