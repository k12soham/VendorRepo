import axios from 'axios';

const API_URL = 'http://localhost:8095';

export const api = axios.create({
    baseURL: API_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

export const getAllEmployees = () => api.get('/employees/getAllEmployees');
export const saveEmployee = (employee) => api.post('/employees/saveEmployee', employee);
export const getAllVendors = () => api.get('/vendors/getAllVendors');
export const saveVendor = (vendor) => api.post('/vendors/saveVendor', vendor);
export const sendEmailToSelectedVendors = (vendorIds) => api.post('/vendors/sendEmails', vendorIds);
export const getAllEmailLogs = () => api.get('/email-logs/getEmailLog');

